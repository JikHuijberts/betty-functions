import { default as insertExpression_1_0 } from './functions/insert-expression/1.0';
import { default as updateExpressions_1_0 } from './functions/update-expressions/1.0';
import { default as updateExpressions_1_1 } from './functions/update-expressions/1.1';

const fn = {
  "insertExpression 1.0": insertExpression_1_0,
  "updateExpressions 1.0": updateExpressions_1_0,
  "updateExpressions 1.1": updateExpressions_1_1,
};

export default fn;
